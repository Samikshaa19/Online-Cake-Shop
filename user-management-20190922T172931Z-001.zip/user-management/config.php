<?php
$smtphost = "Your SMTP Host Name";
$smtpuser = "SMTP User Name";
$smtppass = "SMTP Password";
$secret = "Google Recaptcha Secret Key";
?>